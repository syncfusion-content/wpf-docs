---
layout: post
title: Windows 7 Default Window Behavior | Ribbon | WPF | Syncfusion
description: windows 7 default window behavior
platform: wpf
control: Ribbon
documentation: ug
---

# Windows 7 Default Window Behavior

Syncfusion’s Tools WPF Ribbon Window has now extended its support to all the default behaviors of Windows 7.

## Feature Details

This feature allows you to drag the Ribbon Window while in its Maximized state. While dragging the Ribbon Window, it will go to its normal state with respect to the mouse pointer. 

All default behavior of Windows 7 applies only when IsGlassActive mode is True in Ribbon Window.

