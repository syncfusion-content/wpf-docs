---
layout: post
title: Scrolling Ribbon Tab and Ribbon Bar | Ribbon | WPF | Syncfusion
description: scrolling ribbon tab and ribbon bar
platform: wpf
control: Ribbon
documentation: ug
---

# Scrolling Ribbon Tab and Ribbon Bar

With the new Ribbon instance, you can scroll the Ribbon Tab and Ribbon Bar to and fro, in order to navigate through the controls in the Ribbon Bar and Ribbon Tab. This support adds quality to the application created by using a Ribbon instance.



![](Scrolling-Ribbon-Tab-and-Ribbon-Bar_images/Scrolling-Ribbon-Tab-and-Ribbon-Bar_img1.jpeg)




![](Scrolling-Ribbon-Tab-and-Ribbon-Bar_images/Scrolling-Ribbon-Tab-and-Ribbon-Bar_img2.jpeg)




