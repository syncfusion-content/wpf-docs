---
layout: post
title: Touch Support
description: Touch Support
platform: wpf
control: Ribbon
documentation: ug
---
## Touch Support

Touch styles can be applied to a control by setting the **EnableTouch** property defined in the **SkinStorage** class to **True**. 

### How to enable touch in RibbonWindow?

To enable touch in the RibbonWindow, set **EnableTouch** property of the SkinStorage as “**True**”.The following code snippet illustrates this

{% highlight xml %}

[XAML]

<syncfusion:RibbonWindow

xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"

xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"

xmlns:syncfusion="http://schemas.syncfusion.com/wpf" x:Class="RibbonButtonPanel.MainWindow"

Title="MainWindow" Height="350" Width="525" syncfusion:SkinStorage.VisualStyle="Office2013"  x:Name="RibbonWindow" syncfusion:SkinStorage.EnableTouch="True"/>

{% endhighlight %}

{% highlight c# %}

[C#]

SkinStorage.SetEnableTouch(RibbonWindow, true);

{% endhighlight %}

![](TouchSupport_images/TouchSupport_img1.jpeg)
